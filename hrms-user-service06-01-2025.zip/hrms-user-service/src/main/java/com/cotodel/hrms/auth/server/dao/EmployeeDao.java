package com.cotodel.hrms.auth.server.dao;

import com.cotodel.hrms.auth.server.entity.EmployeeEntity;

public interface EmployeeDao {
	public EmployeeEntity saveDetails(EmployeeEntity employeeEntity);
}
