/**
 * @author vinay
 *
 * 
 */
package com.cotodel.hrms.auth.server.service;

import java.util.List;

import com.cotodel.hrms.auth.server.entity.SectorMaster;

/**
 * 
 */
public interface SectorMasterService {
	
	public List<SectorMaster> getBySectorList();
	
}
