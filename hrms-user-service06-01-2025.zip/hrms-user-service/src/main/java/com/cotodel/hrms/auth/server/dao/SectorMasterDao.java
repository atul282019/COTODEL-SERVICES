package com.cotodel.hrms.auth.server.dao;

import java.util.List;

import com.cotodel.hrms.auth.server.entity.SectorMaster;

public interface SectorMasterDao {
	public List<SectorMaster> getBySectorList();
}
