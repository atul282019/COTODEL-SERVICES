package com.cotodel.hrms.auth.server.service.impl;

/**
 * @author vinay
 */
import org.springframework.stereotype.Service;

import com.cotodel.hrms.auth.server.service.DatabaseMasterService;

@Service
public class DatabaseMasterServiceimpl implements DatabaseMasterService {

}
