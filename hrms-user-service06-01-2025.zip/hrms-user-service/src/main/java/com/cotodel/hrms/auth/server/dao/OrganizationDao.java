package com.cotodel.hrms.auth.server.dao;

import java.util.List;

import com.cotodel.hrms.auth.server.entity.OrganizationMaster;

public interface OrganizationDao {
	
	public List<OrganizationMaster>  getOrganizationMaster();

}
