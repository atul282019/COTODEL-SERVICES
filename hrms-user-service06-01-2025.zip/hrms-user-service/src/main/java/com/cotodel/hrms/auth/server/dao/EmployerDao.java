package com.cotodel.hrms.auth.server.dao;

import com.cotodel.hrms.auth.server.entity.EmployerEntity;

public interface EmployerDao {
	public EmployerEntity saveDetails(EmployerEntity employerEntity);
}
