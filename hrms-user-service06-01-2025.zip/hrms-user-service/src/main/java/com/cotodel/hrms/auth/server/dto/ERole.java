package com.cotodel.hrms.auth.server.dto;

public enum ERole {
  EMPLOYEE,
  EMPLOYER,
  ADMIN,
  APPROVER,
  SUPERADMIN,
  HR_MANAGER,
  MANAGER,
  EX_EMPLOYEE
}
