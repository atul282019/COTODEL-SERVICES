package com.cotodel.hrms.auth.server.service;

import java.util.List;

import com.cotodel.hrms.auth.server.entity.OrganizationMaster;

public interface OrganizationMasterService {
	
	public List<OrganizationMaster>  getOrganizationMaster();


}
