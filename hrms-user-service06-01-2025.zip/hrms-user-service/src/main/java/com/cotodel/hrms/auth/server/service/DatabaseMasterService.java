package com.cotodel.hrms.auth.server.service;

/**
 * @author vinay
 */
public interface DatabaseMasterService {

}
