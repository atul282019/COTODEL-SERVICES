package com.example.auth_server;

/*
 * @SpringBootTest class AuthServerApplicationTests {
 * 
 * @Test void contextLoads() { }
 * 
 * }
 */
