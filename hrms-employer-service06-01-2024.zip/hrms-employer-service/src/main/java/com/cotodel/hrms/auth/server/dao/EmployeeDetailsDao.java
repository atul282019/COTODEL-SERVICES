package com.cotodel.hrms.auth.server.dao;

import java.util.List;

import com.cotodel.hrms.auth.server.model.EmployeeDetailsEntity;

public interface EmployeeDetailsDao {
	public EmployeeDetailsEntity saveDetails(EmployeeDetailsEntity employeeEntity);
	public List<EmployeeDetailsEntity> getEmployeeDetails(Long emplrid);
}
