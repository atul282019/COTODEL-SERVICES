package com.cotodel.hrms.auth.server.service;

import com.cotodel.hrms.auth.server.dto.EmployeeDetailsRequest;

public interface EmployeeDetailsService {
	
	public EmployeeDetailsRequest  saveEmpDetails(EmployeeDetailsRequest request);	
	
	
}
