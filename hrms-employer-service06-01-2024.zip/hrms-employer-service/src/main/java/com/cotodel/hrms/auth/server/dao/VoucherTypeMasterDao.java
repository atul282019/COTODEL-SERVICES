package com.cotodel.hrms.auth.server.dao;

import com.cotodel.hrms.auth.server.model.VoucherTypeMasterEntity;

public interface VoucherTypeMasterDao {
	public VoucherTypeMasterEntity saveDetails(VoucherTypeMasterEntity voucherTypeMasterEntity);
	
}
