package com.cotodel.hrms.auth.server.dao;

import com.cotodel.hrms.auth.server.model.EmployeePayrollEntity;

public interface EmployeePayrollDao {
	public EmployeePayrollEntity saveDetails(EmployeePayrollEntity employeePayrollEntity);
}
