package com.cotodel.hrms.auth.server.util;

public enum AccountType {
	SAVING, CURRENT;
}
