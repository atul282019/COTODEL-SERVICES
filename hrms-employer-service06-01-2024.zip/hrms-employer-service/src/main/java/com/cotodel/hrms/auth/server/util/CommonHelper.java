package com.cotodel.hrms.auth.server.util;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
@Repository
public class CommonHelper {
	@Autowired
    private EntityManager entityManager;
	
	
    
   
}
