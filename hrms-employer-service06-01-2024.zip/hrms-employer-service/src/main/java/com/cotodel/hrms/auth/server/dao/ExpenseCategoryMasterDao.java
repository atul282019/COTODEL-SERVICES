package com.cotodel.hrms.auth.server.dao;

import java.util.List;

import com.cotodel.hrms.auth.server.model.ExpenseCategoryMasterEntity;

public interface ExpenseCategoryMasterDao {	
	public List<ExpenseCategoryMasterEntity> getExpenseCategoryMaster();
	
}
