package com.cotodel.hrms.auth.server.dao;

import com.cotodel.hrms.auth.server.model.BandEntity;

public interface BandDao {
	public BandEntity saveDetails(BandEntity bandEntity);
}
