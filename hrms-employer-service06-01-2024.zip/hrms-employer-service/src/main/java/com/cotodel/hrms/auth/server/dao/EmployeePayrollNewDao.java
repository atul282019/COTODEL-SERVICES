package com.cotodel.hrms.auth.server.dao;

import com.cotodel.hrms.auth.server.model.EmployeePayrollNewEntity;

public interface EmployeePayrollNewDao {
	public EmployeePayrollNewEntity saveDetails(EmployeePayrollNewEntity employeePayrollNewEntity);
}
