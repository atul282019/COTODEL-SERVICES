package com.cotodel.hrms.auth.server.dao;

import com.cotodel.hrms.auth.server.model.ErupiBankMasterEntity;

public interface BankMasterDao {
	public ErupiBankMasterEntity saveDetails(ErupiBankMasterEntity erupiBankMasterEntity);
	public ErupiBankMasterEntity getDetails(String bankCode);
}
