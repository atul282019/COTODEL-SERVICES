package com.cotodel.hrms.auth.server.service;

import java.util.List;

import com.cotodel.hrms.auth.server.dto.ManagerMasterRequest;
import com.cotodel.hrms.auth.server.model.ManagerLblMasterEntity;

public interface ManagerMasterService {
	
	public ManagerMasterRequest  saveManagerMaster(ManagerMasterRequest bankMasterRequest);	
	public List<ManagerLblMasterEntity>  getManagerMaster(Long orgId);
	
	
	
}
