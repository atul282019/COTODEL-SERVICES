package com.cotodel.hrms.auth.server.dao;

import com.cotodel.hrms.auth.server.model.EmployeePayrollTaxEntity;

public interface EmployeePayrollTaxDao {
	public EmployeePayrollTaxEntity saveDetails(EmployeePayrollTaxEntity employeePayrollTaxEntity);
}
