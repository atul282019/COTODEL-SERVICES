package com.cotodel.hrms.auth.server.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.ObjectUtils;

import com.cotodel.hrms.auth.server.dao.EmployeeOnboardingDao;
import com.cotodel.hrms.auth.server.dto.EmployeeOnboardingNewRequest;
import com.cotodel.hrms.auth.server.dto.EmployeeOnboardingRequest;
import com.cotodel.hrms.auth.server.dto.UserRequest;
import com.cotodel.hrms.auth.server.model.EmployeeOnboardingEntity;
import com.cotodel.hrms.auth.server.properties.ApplicationConstantConfig;
import com.cotodel.hrms.auth.server.service.EmployeeOnboardingService;
import com.cotodel.hrms.auth.server.util.CommonUtility;
import com.cotodel.hrms.auth.server.util.CommonUtils;
import com.cotodel.hrms.auth.server.util.CopyUtility;
import com.cotodel.hrms.auth.server.util.MessageConstant;
@Repository
public class EmployeeOnboardingServiceImpl implements EmployeeOnboardingService{

	@Autowired
	EmployeeOnboardingDao  employeeOnboardingDao;
	
	@Autowired
	ApplicationConstantConfig  applicationConstantConfig;
	
	@Autowired
    private EntityManager entityManager;
	
	@Override
	public EmployeeOnboardingRequest saveEmployeeDetails(EmployeeOnboardingRequest request) {
		
		String response="";
		String response1="";
		String tokenvalue="";
		TokenGeneration token=new TokenGeneration();
		UserRequest userRequest=new UserRequest();
		try {
			tokenvalue = token.getToken(applicationConstantConfig.authTokenApiUrl+CommonUtils.getToken);
			userRequest.setUsername(request.getName());
			userRequest.setMobile(request.getMobile());
			userRequest.setEmail(request.getEmail());
			userRequest.setEmployerid(request.getEmployerId()==null?0:request.getEmployerId().intValue());
			response1 = CommonUtility.userRequest(tokenvalue, MessageConstant.gson.toJson(userRequest),
					applicationConstantConfig.userServiceApiUrl+CommonUtils.saveUsersWithOutMail);
			if (!ObjectUtils.isEmpty(response1)) {
				JSONObject demoRes = new JSONObject(response1);
				boolean status = demoRes.getBoolean("status");
				if (status) {
					Long id=0l;
					if (demoRes.has("userEntity")) {
						JSONObject userEntity = demoRes.getJSONObject("userEntity");
						id=userEntity.getLong("id");
						
					}
					//String user = demoRes.getString("userEntity");
					//JSONObject refData=pendJosnIdRes.getJSONArray("data").getJSONObject(0);
					response = MessageConstant.RESPONSE_FAILED;
					request.setResponse(response);
					EmployeeOnboardingEntity employeeOnboarding = new EmployeeOnboardingEntity();
					CopyUtility.copyProperties(request, employeeOnboarding);
					employeeOnboarding.setUserDetailsId(id);
					employeeOnboarding.setMode(1l);
					//employeeOnboarding.setEmpCode();
					String empcode=request.getEmployerId()+"";
					employeeOnboarding = employeeOnboardingDao.saveDetails(employeeOnboarding);
					response = MessageConstant.RESPONSE_SUCCESS;
					request.setResponse(response);
				} else if (!status) {
					response = demoRes.getString("message");
					request.setResponse(response);
				}

			}
		} catch (Exception e) {
			response = MessageConstant.RESPONSE_FAILED;
			request.setResponse(response);
		}
		return request;

	}


	@Override
	public List<EmployeeOnboardingEntity> getEmployeeDetailsList(Long employerid) {
		List<EmployeeOnboardingEntity> employeeOnboading=null;
		try {
			employeeOnboading=employeeOnboardingDao.getEmployeeOnboardingList(employerid);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return employeeOnboading;
	}


	@Override
	public EmployeeOnboardingRequest saveBulkEmployeeDetails(EmployeeOnboardingRequest request) {
		String response="";
		String response1="";
		String tokenvalue="";
		TokenGeneration token=new TokenGeneration();
		UserRequest userRequest=new UserRequest();
		try {
			tokenvalue = token.getToken(applicationConstantConfig.authTokenApiUrl+CommonUtils.getToken);
			userRequest.setUsername(request.getName());
			userRequest.setMobile(request.getMobile());
			userRequest.setEmail(request.getEmail());
			userRequest.setEmployerid(request.getEmployerId()==null?0:request.getEmployerId().intValue());
			userRequest.setUpdateStatus(request.isUpdateStatus());
			userRequest.setUpdateStatus(request.isEmailStatus());
			
			response1 = CommonUtility.userRequest(tokenvalue, MessageConstant.gson.toJson(userRequest),
					applicationConstantConfig.userServiceApiUrl+CommonUtils.saveUsersBulk);
			if (!ObjectUtils.isEmpty(response1)) {
				JSONObject demoRes = new JSONObject(response1);
				boolean status = demoRes.getBoolean("status");
				if (status) {
					Long id=0l;
					if (demoRes.has("userEntity")) {
						JSONObject userEntity = demoRes.getJSONObject("userEntity");
						id=userEntity.getLong("id");
						
					}
					response = MessageConstant.RESPONSE_FAILED;
					request.setResponse(response);
					EmployeeOnboardingEntity employeeOnboarding = new EmployeeOnboardingEntity();
					CopyUtility.copyProperties(request, employeeOnboarding);
					employeeOnboarding.setUserDetailsId(id);
					employeeOnboarding.setMode(2l);
					String empCode=getEmpCode(request.getEmployerId());
					employeeOnboarding.setEmpCode(empCode);
					employeeOnboarding = employeeOnboardingDao.saveDetails(employeeOnboarding);
					response = MessageConstant.RESPONSE_SUCCESS;
					request.setResponse(response);
				} else if (!status) {
					response = demoRes.getString("message");
					request.setResponse(response);
				}

			}
		} catch (Exception e) {
			response = MessageConstant.RESPONSE_FAILED;
			request.setResponse(response);
		}
		return request;

	}


	@Override
	public List<EmployeeOnboardingRequest> confirmBulkEmployeeDetails(List<EmployeeOnboardingRequest> request) {
		String response="";
		String response1="";
		String tokenvalue="";
		
		TokenGeneration token=new TokenGeneration();
		UserRequest userRequest=new UserRequest();
		try {
			tokenvalue = token.getToken(applicationConstantConfig.authTokenApiUrl+CommonUtils.getToken);
			for (EmployeeOnboardingRequest employeeOnboardingRequest : request) {
				
			
			userRequest.setUsername(employeeOnboardingRequest.getName());
			userRequest.setMobile(employeeOnboardingRequest.getMobile());
			userRequest.setEmail(employeeOnboardingRequest.getEmail());
			userRequest.setEmployerid(employeeOnboardingRequest.getEmployerId()==null?0:employeeOnboardingRequest.getEmployerId().intValue());
			response1 = CommonUtility.userRequest(tokenvalue, MessageConstant.gson.toJson(userRequest),
					applicationConstantConfig.userServiceApiUrl+CommonUtils.updateUser);
			if (!ObjectUtils.isEmpty(response1)) {
				JSONObject demoRes = new JSONObject(response1);
				boolean status = demoRes.getBoolean("status");
				if (status) {
					Long id=0l;
					if (demoRes.has("userEntity")) {
						JSONObject userEntity = demoRes.getJSONObject("userEntity");
						id=userEntity.getLong("id");
						
					}
					//String user = demoRes.getString("userEntity");
					//JSONObject refData=pendJosnIdRes.getJSONArray("data").getJSONObject(0);
					
					response = MessageConstant.RESPONSE_FAILED;
					employeeOnboardingRequest.setResponse(response);
					EmployeeOnboardingEntity employeeOnboarding = new EmployeeOnboardingEntity();
					employeeOnboarding=employeeOnboardingDao.getEmployeeOnboarding(employeeOnboardingRequest.getMobile());
					//CopyUtility.copyProperties(request, employeeOnboarding);
					//employeeOnboarding.setUserDetailsId(id);
					//employeeOnboarding.setMode(1l);
					employeeOnboarding.setStatus(1);
					employeeOnboarding = employeeOnboardingDao.saveDetails(employeeOnboarding);
					response = MessageConstant.RESPONSE_SUCCESS;
					employeeOnboardingRequest.setResponse(response);
				} else if (!status) {
					response = demoRes.getString("message");
					employeeOnboardingRequest.setResponse(response);
				}

			}
			}
			
		} catch (Exception e) {
			response = MessageConstant.RESPONSE_FAILED;
			//employeeOnboardingRequest.setResponse(response);
		}
		
		return request;

	}


	@Override
	public List<EmployeeOnboardingRequest> tryBulkEmployeeDetails(List<EmployeeOnboardingRequest> request) {
		
		String response="";
		String response1="";
		String tokenvalue="";
		TokenGeneration token=new TokenGeneration();
		UserRequest userRequest=new UserRequest();
		List<EmployeeOnboardingRequest> emList=new ArrayList<EmployeeOnboardingRequest>();
		for (EmployeeOnboardingRequest employeeOnboardingRequest : request) {
		try {
			tokenvalue = token.getToken(applicationConstantConfig.authTokenApiUrl+CommonUtils.getToken);
			
			userRequest.setUsername(employeeOnboardingRequest.getName());
			userRequest.setMobile(employeeOnboardingRequest.getMobile());
			userRequest.setEmail(employeeOnboardingRequest.getEmail());
			userRequest.setEmployerid(employeeOnboardingRequest.getEmployerId()==null?0:employeeOnboardingRequest.getEmployerId().intValue());
			response1 = CommonUtility.userRequest(tokenvalue, MessageConstant.gson.toJson(userRequest),
					applicationConstantConfig.userServiceApiUrl+CommonUtils.saveUsersWithOutMail);
			if (!ObjectUtils.isEmpty(response1)) {
				JSONObject demoRes = new JSONObject(response1);
				boolean status = demoRes.getBoolean("status");
				if (status) {
					Long id=0l;
					if (demoRes.has("userEntity")) {
						JSONObject userEntity = demoRes.getJSONObject("userEntity");
						id=userEntity.getLong("id");
						
					}
					response = MessageConstant.RESPONSE_FAILED;
					employeeOnboardingRequest.setResponse(response);
					EmployeeOnboardingEntity employeeOnboarding = new EmployeeOnboardingEntity();
					CopyUtility.copyProperties(request, employeeOnboarding);
					employeeOnboarding.setUserDetailsId(id);
					employeeOnboarding.setMode(1l);
					
					employeeOnboarding = employeeOnboardingDao.saveDetails(employeeOnboarding);
					response = MessageConstant.RESPONSE_SUCCESS;
					employeeOnboardingRequest.setResponse(response);
				} else if (!status) {
					response = demoRes.getString("message");
					employeeOnboardingRequest.setResponse(response);
				}

			}
		
		} catch (Exception e) {
			response = MessageConstant.RESPONSE_FAILED;
			employeeOnboardingRequest.setResponse(response);
		}
		emList.add(employeeOnboardingRequest);
		}
		return emList;

	}


	@Override
	public EmployeeOnboardingEntity getEmployeeDetailsById(Long id) {
		EmployeeOnboardingEntity employeeOnboading=new EmployeeOnboardingEntity();
		try {
			employeeOnboading=employeeOnboardingDao.getEmployeeOnboardingId(id);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return employeeOnboading;
		
	}


	@Override
	public EmployeeOnboardingNewRequest saveEmployeeDetailsNew(EmployeeOnboardingNewRequest request) {
		
		String response="";
		String response1="";
		String tokenvalue="";
		TokenGeneration token=new TokenGeneration();
		UserRequest userRequest=new UserRequest();
		try {
			tokenvalue = token.getToken(applicationConstantConfig.authTokenApiUrl+CommonUtils.getToken);
			userRequest.setUsername(request.getName());
			userRequest.setMobile(request.getMobile());
			userRequest.setEmail(request.getEmail());
			userRequest.setEmployerid(request.getEmployerId()==null?0:request.getEmployerId().intValue());
			response1 = CommonUtility.userRequest(tokenvalue, MessageConstant.gson.toJson(userRequest),
					applicationConstantConfig.userServiceApiUrl+CommonUtils.saveUsersWithOutMailNew);
			if (!ObjectUtils.isEmpty(response1)) {
				JSONObject demoRes = new JSONObject(response1);
				boolean status = demoRes.getBoolean("status");
				if (status || !status) {
					Long id=0l;
					if (demoRes.has("userEntity")) {
						JSONObject userEntity = demoRes.getJSONObject("userEntity");
						id=userEntity.getLong("id");
						
					}
					//String user = demoRes.getString("userEntity");
					//JSONObject refData=pendJosnIdRes.getJSONArray("data").getJSONObject(0);
					response = MessageConstant.RESPONSE_FAILED;
					request.setResponse(response);
					EmployeeOnboardingEntity employeeOnboarding = new EmployeeOnboardingEntity();
					employeeOnboarding=employeeOnboardingDao.getEmployeeOnboarding(request.getMobile());
					if(employeeOnboarding!=null) {
						employeeOnboarding.setProofOfIdentity(request.getProofOfIdentity());
						employeeOnboarding.setPan(request.getPan());
						employeeOnboarding.setBankAccountNumber(request.getBankAccountNumber());
						employeeOnboarding.setIfscCode(request.getIfscCode());
						employeeOnboarding.setBeneficiaryName(request.getBeneficiaryName());
					}else {
						employeeOnboarding = new EmployeeOnboardingEntity();
						CopyUtility.copyProperties(request, employeeOnboarding);
					}
					
					employeeOnboarding.setUserDetailsId(id);
					employeeOnboarding.setMode(1l);
					employeeOnboarding = employeeOnboardingDao.saveDetails(employeeOnboarding);
					response = MessageConstant.RESPONSE_SUCCESS;
					request.setResponse(response);
					request.setId(employeeOnboarding.getId());
				} else if (!status) {
					response = demoRes.getString("message");
					request.setResponse(response);
				}

			}
		} catch (Exception e) {
			response = MessageConstant.RESPONSE_FAILED;
			request.setResponse(response);
		}
		return request;

	}
	
	public long generateId() {
        Query query = entityManager.createNativeQuery("SELECT nextval('empcode')");
        return ((Number) query.getSingleResult()).longValue();
    }
    
    public String getEmpCode(Long orgid) {
    	orgid=orgid==null?0:orgid;
    	String value=getEmpNo();
    	
        String uniqueId=orgid+value;
        System.out.println(uniqueId);
    	return uniqueId;
    }
    public String getEmpNo() {
    	
    	String value=String.valueOf(generateId());
    	int len =value.length();
    	String finalValue="";
        switch (len) {
            case 1:
            	finalValue="0000"+value;
                break;
            case 2:
            	finalValue="000"+value;
                break;
            case 3:
            	finalValue="00"+value;
                break;
            case 4:
            	finalValue="0"+value;
                break;
            default:
            	finalValue=value;
        }
    	
        System.out.println(finalValue);
    	return finalValue;
    }
	
}
